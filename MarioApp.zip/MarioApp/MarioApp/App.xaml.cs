﻿namespace MarioApp
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            MainPage = new AppShell(); // Establecer AppShell como la página principal
        }
    }
}
