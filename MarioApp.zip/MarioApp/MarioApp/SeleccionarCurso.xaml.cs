﻿using Microsoft.Maui.Controls;

namespace MarioApp
{
    public partial class SeleccionarCurso : ContentPage
    {
        private DatosMatricula _datosMatricula;

        public SeleccionarCurso(DatosMatricula datosMatricula)
        {
            InitializeComponent();
            _datosMatricula = datosMatricula;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            var tapGesture1 = new TapGestureRecognizer();
            tapGesture1.Tapped += (s, e) => {
                _datosMatricula.ActualizarDatos("Curso 1", 100);
                Navigation.PopAsync();
            };
            curso1.GestureRecognizers.Add(tapGesture1);

            var tapGesture2 = new TapGestureRecognizer();
            tapGesture2.Tapped += (s, e) => {
                _datosMatricula.ActualizarDatos("Curso 2", 200);
                Navigation.PopAsync();
            };
            curso2.GestureRecognizers.Add(tapGesture2);
        }
    }
}
