﻿namespace MarioApp
{
    public partial class AppShell : Shell
    {
        public AppShell()
        {
            InitializeComponent();
            Routing.RegisterRoute(nameof(DatosMatricula), typeof(DatosMatricula));
            Routing.RegisterRoute(nameof(SeleccionarCurso), typeof(SeleccionarCurso));
            Routing.RegisterRoute(nameof(SeleccionarFormaPago), typeof(SeleccionarFormaPago));
        }

        public async void NavigateToDatosMatricula(string nombreUsuario, string emailUsuario)
        {
            // Puedes pasar parámetros al navegar
            await Shell.Current.GoToAsync($"{nameof(DatosMatricula)}?nombre={nombreUsuario}&email={emailUsuario}");
        }
    }
}
