﻿using Microsoft.Maui.Controls;

namespace MarioApp
{
    [QueryProperty(nameof(CursoSeleccionado), "curso")]
    [QueryProperty(nameof(PrecioCurso), "precio")]
    public partial class DatosMatricula : ContentPage
    {
        public string CursoSeleccionado { get; set; } = string.Empty;
        public decimal PrecioCurso { get; set; }
        public string FormaPagoSeleccionada { get; set; } = string.Empty;

        public DatosMatricula()
        {
            InitializeComponent();
        }

        private void OnSeleccionarCursoClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new SeleccionarCurso(this));
        }

        private void OnSeleccionarFormaPagoClicked(object sender, EventArgs e)
        {
            Navigation.PushAsync(new SeleccionarFormaPago(this));
        }

        private void OnCalcularPrecioClicked(object sender, EventArgs e)
        {
            if (FormaPagoSeleccionada == "Al contado")
                labelResultado.Text = $"Precio final: {PrecioCurso:C}";
            else
                labelResultado.Text = $"Precio final: {(PrecioCurso * 0.9m):C} (10% de descuento)";
        }

        public void ActualizarDatos(string curso, decimal precio)
        {
            CursoSeleccionado = curso;
            PrecioCurso = precio;
            labelCurso.Text = curso;
            labelPrecio.Text = precio.ToString("C");

            btnCalcularPrecio.IsEnabled = !string.IsNullOrEmpty(labelCurso.Text) &&
                                          !string.IsNullOrEmpty(labelFormaPago.Text);
        }

        public void ActualizarFormaPago(string formaPago)
        {
            FormaPagoSeleccionada = formaPago;
            labelFormaPago.Text = formaPago;

            btnCalcularPrecio.IsEnabled = !string.IsNullOrEmpty(labelCurso.Text) &&
                                          !string.IsNullOrEmpty(labelFormaPago.Text);
        }
    }
}
