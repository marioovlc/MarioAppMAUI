﻿using Microsoft.Maui.Controls;

namespace MarioApp
{
    public partial class SeleccionarFormaPago : ContentPage
    {
        private DatosMatricula _datosMatricula;

        public SeleccionarFormaPago(DatosMatricula datosMatricula)
        {
            InitializeComponent();
            _datosMatricula = datosMatricula;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();

            var cashTapGesture = new TapGestureRecognizer();
            cashTapGesture.Tapped += (s, e) => {
                _datosMatricula.ActualizarFormaPago("Al contado");
                Navigation.PopAsync();
            };
            efectivo.GestureRecognizers.Add(cashTapGesture);

            var cardTapGesture = new TapGestureRecognizer();
            cardTapGesture.Tapped += (s, e) => {
                _datosMatricula.ActualizarFormaPago("Con tarjeta");
                Navigation.PopAsync();
            };
            tarjeta.GestureRecognizers.Add(cardTapGesture);
        }
    }
}
